// AQUIL Alliance Website Logic & Translations

const translations = {
    de: {
        // Navigation (Shared)
        "nav_home": "Home",
        "nav_about": "Über uns",
        "nav_services": "Leistungen",
        "nav_contact": "Kontakt",
        "nav_service_general": "Gebäudereinigung",
        "nav_service_maintenance": "Unterhaltsreinigung",
        "nav_service_special": "Sonderreinigung",
        "btn_inquire": "Jetzt Anfragen",
        "phone_call": "0511 11721912",

        // Home Page
        "hero_title_1": "Professionell.",
        "hero_title_2": "Zuverlässig.",
        "hero_desc": "Ihre Sauberkeit ist unser Anspruch. Kompromisslose Qualität und deutsche Ingenieurs-Präzision in der Gebäudereinigung für anspruchsvolle B2B Kunden in Hannover und Region.",
        "hero_cta_inquire": "Jetzt Anfragen",
        "hero_cta_discover": "Leistungen entdecken",
        "val_1_title": "Termintreu",
        "val_1_desc": "Absolute Pünktlichkeit. Wir integrieren uns nahtlos in Ihre Betriebsabläufe, ohne diese zu stören.",
        "val_2_title": "Detailliert",
        "val_2_desc": "Mikroskopische Präzision. Wir reinigen nicht nur Flächen, wir pflegen den Wert Ihrer Immobilien.",
        "val_3_title": "Vertrauensvoll",
        "val_3_desc": "Sicherheit und Diskretion. Vertrauen ist das Fundament unserer langfristigen Partnerschaften.",
        "val_4_title": "Umweltbewusst",
        "val_4_desc": "Nachhaltige Reinigungskonzepte und umweltschonende Mittel für eine saubere Zukunft.",
        "services_sub": "Kernkompetenzen",
        "services_title": "Unser Leistungsportfolio",
        "services_all": "Alle Leistungen",
        "srv_1_num": "01",
        "srv_1_title": "Gebäudereinigung",
        "srv_1_desc": "Umfassende Pflege Ihrer Immobilien. Von der Fassade bis zum Tiefgaragenboden. Wir garantieren Werterhalt und ein makelloses Erscheinungsbild für Ihre repräsentativen Objekte.",
        "srv_1_bullet_1": "Fassaden- & Glasreinigung",
        "srv_1_bullet_2": "Treppenhausreinigung",
        "srv_1_bullet_3": "Außenanlagenpflege",
        "srv_1_details": "Details ansehen",
        "srv_2_num": "02",
        "srv_2_title": "Unterhaltsreinigung",
        "srv_2_desc": "Regelmäßige Reinigung nach festen Intervallen. Perfekt für Büros, Praxen und Kanzleien.",
        "srv_2_details": "Mehr erfahren",
        "srv_3_num": "03",
        "srv_3_title": "Sonderreinigung",
        "srv_3_desc": "Speziallösungen für harte Fälle. Grundreinigung, Bauendreinigung und Industrieanlagen.",
        "srv_3_details": "Mehr erfahren",
        "promise_title": "Unser Versprechen",
        "promise_desc": "Wir reagieren innerhalb von 2 Stunden auf Ihre Anfrage während der Geschäftszeiten. Garantiert. Hinterlassen Sie Ihre Nummer, und wir rufen Sie umgehend für ein erstes, unverbindliches Beratungsgespräch zurück.",
        "promise_phone_label": "Direktkontakt",
        "callback_title": "Rückruf anfordern",
        "form_label_name": "Name / Firma",
        "form_placeholder_name": "Max Mustermann GmbH",
        "form_label_phone": "Telefonnummer",
        "form_placeholder_phone": "+49 (0) ...",
        "form_btn_submit": "Rückruf anfordern",
        "form_disclaimer": "Mit dem Absenden dieses Formulars stimmen Sie unserer Datenschutzerklärung zu. Wir nutzen Ihre Daten ausschließlich zur Kontaktaufnahme.",
        "form_success_title": "Anfrage erfolgreich gesendet",
        "form_success_msg": "Vielen Dank für Ihre Anfrage. Wir werden uns innerhalb der nächsten 2 Stunden bei Ihnen melden.",
        "form_error_empty": "Bitte füllen Sie alle Pflichtfelder aus.",
        "form_error_phone": "Bitte geben Sie eine gültige Telefonnummer ein.",

        // Stats Section
        "stats_title": "AQUIL in Zahlen",
        "stat_1_number": "500+",
        "stat_1_label": "Gereinigte Objekte",
        "stat_2_number": "99%",
        "stat_2_label": "Kundenzufriedenheit",
        "stat_3_number": "2h",
        "stat_3_label": "Reaktionszeit",
        "stat_4_number": "24/7",
        "stat_4_label": "Notdienst verfügbar",

        // Testimonials Section
        "testimonials_sub": "Kundenstimmen",
        "testimonials_title": "Was unsere Kunden sagen",
        "testimonial_1_text": "AQUIL Alliance hat unsere Erwartungen übertroffen. Die Gründlichkeit und Zuverlässigkeit ihres Teams ist beispiellos. Unsere Büros waren noch nie so sauber.",
        "testimonial_1_name": "Thomas Richter",
        "testimonial_1_role": "Geschäftsführer, Richter Immobilien GmbH",
        "testimonial_2_text": "Als Praxisinhaber lege ich höchsten Wert auf Hygiene. AQUIL liefert konstant erstklassige Ergebnisse. Die Kommunikation ist vorbildlich.",
        "testimonial_2_name": "Dr. Sabine Weber",
        "testimonial_2_role": "Inhaberin, Zahnarztpraxis Weber",
        "testimonial_3_text": "Seit wir mit AQUIL zusammenarbeiten, haben wir keine einzige Beschwerde mehr erhalten. Pünktlich, diskret und absolut professionell.",
        "testimonial_3_name": "Michael Hoffmann",
        "testimonial_3_role": "Facility Manager, Expo Park Hannover",

        // Process Section
        "process_sub": "So arbeiten wir",
        "process_title": "In 4 Schritten zu Ihrem sauberen Objekt",
        "process_1_title": "Anfrage",
        "process_1_desc": "Kontaktieren Sie uns per Telefon, E-Mail oder Formular. Wir melden uns innerhalb von 2 Stunden.",
        "process_2_title": "Besichtigung",
        "process_2_desc": "Wir besichtigen Ihr Objekt kostenlos und erstellen ein maßgeschneidertes Reinigungskonzept.",
        "process_3_title": "Angebot",
        "process_3_desc": "Sie erhalten ein transparentes, faires Angebot ohne versteckte Kosten.",
        "process_4_title": "Umsetzung",
        "process_4_desc": "Unser geschultes Team beginnt termingerecht mit der professionellen Reinigung.",

        // Trust Marquee
        "trust_item_1": "Professionell",
        "trust_item_2": "Zuverlässig",
        "trust_item_3": "Termintreu",
        "trust_item_4": "Umweltbewusst",
        "trust_item_5": "Hannover & Region",
        "trust_item_6": "B2B Spezialist",

        // About Us Page (about.html)
        "about_hero_title": "Über uns",
        "about_hero_desc": "Lernen Sie die AQUIL Alliance und unsere Werte kennen. Wir stehen für Zuverlässigkeit, Präzision und Werterhalt Ihrer Gewerbeimmobilien.",
        "about_story_title": "Unsere Geschichte",
        "about_story_p1": "Die AQUIL Alliance wurde von Scott Gerke als inhabergeführtes Einzelunternehmen in Hannover gegründet. Ausgerichtet auf die Bedürfnisse anspruchsvoller B2B-Kunden bieten wir maßgeschneiderte Reinigungslösungen mit einem klaren Qualitätsversprechen.",
        "about_story_p2": "Wir verstehen uns nicht als reiner Dienstleister, sondern als langfristiger Partner für das Facility Management. Unsere flachen Hierarchien garantieren Ihnen schnelle Reaktionszeiten und einen festen, kompetenten Ansprechpartner vor Ort.",
        "about_values_title": "Was uns auszeichnet",
        "about_val_1_title": "Inhabergeführt",
        "about_val_1_desc": "Direkte Verantwortung durch Scott Gerke. Keine langen Kommunikationswege, sondern prompte Entscheidungen.",
        "about_val_2_title": "Hannover & Region",
        "about_val_2_desc": "Wir sind lokal verankert und schnell vor Ort. Kurze Anfahrtswege ermöglichen hohe Flexibilität und Notfalleinsätze.",
        "about_val_3_title": "Moderne Ausrüstung",
        "about_val_3_desc": "Wir reinigen mit modernsten Geräten und umweltschonenden Wirkstoffen für erstklassige Ergebnisse.",
        "about_quality_title": "Qualitätsgarantie",
        "about_quality_desc": "Durch regelmäßige Objektkontrollen und geschultes Stammpersonal sichern wir ein dauerhaft hohes Reinigungsniveau. Unser Qualitätsversprechen ist für uns nicht verhandelbar.",

        // Services Page (services.html)
        "services_hero_title": "Leistungen",
        "services_hero_desc": "Unser Leistungsspektrum umfasst alle Facetten der professionellen B2B-Gebäudereinigung. Erfahren Sie hier mehr über unsere Kernkompetenzen.",
        "services_cta_inquire": "Dienstleistung anfragen",
        "services_item_1_title": "Gebäudereinigung",
        "services_item_1_desc": "Eine gepflegte Immobilie ist die Visitenkarte Ihres Unternehmens. Wir übernehmen die vollumfängliche Innen- und Außenreinigung Ihrer gewerblichen Objekte, um einen nachhaltigen Werterhalt zu sichern.",
        "services_item_1_li1": "Glas-, Rahmen- und Fassadenreinigung",
        "services_item_1_li2": "Treppenhäuser, Flure und Foyers",
        "services_item_1_li3": "Tiefgaragen, Parkplätze und Gehwege",
        "services_item_1_li4": "Sanitär- und Aufenthaltsräume",
        "services_item_2_title": "Unterhaltsreinigung",
        "services_item_2_desc": "Die regelmäßige Unterhaltsreinigung in festgelegten Intervallen sorgt für ein hygienisches und produktives Arbeitsklima in Ihren Büros, Kanzleien oder Praxen.",
        "services_item_2_li1": "Arbeitsplatz- und Schreibtischreinigung",
        "services_item_2_li2": "Bodenpflege (Saugen, Feuchtwischen)",
        "services_item_2_li3": "Entleerung von Müllbehältern & fachgerechte Mülltrennung",
        "services_item_2_li4": "Küche, Teeküche und Kaffeemaschinen-Pflege",
        "services_item_3_title": "Sonderreinigung",
        "services_item_3_desc": "Spezielle Anforderungen erfordern professionelle Speziallösungen. Wir führen intensive Reinigungsarbeiten durch, die über die normale Unterhaltspflege hinausgehen.",
        "services_item_3_li1": "Bauendreinigung (nach Neubau oder Sanierung)",
        "services_item_3_li2": "Grundreinigung und Versiegelung von Hartböden",
        "services_item_3_li3": "Teppichgrundreinigung und Polstershampoonierung",
        "services_item_3_li4": "Industrieanlagen- und Maschinenreinigung",

        // Inquiry Page (inquiry.html)
        "inq_hero_title": "Jetzt Anfragen",
        "inq_hero_desc": "Fordern Sie ein kostenloses, individuelles Angebot an. Füllen Sie dazu bitte das detaillierte Anfrageformular aus. Wir melden uns umgehend bei Ihnen.",
        "inq_form_header": "Details Ihrer Anfrage",
        "inq_label_company": "Firma / Unternehmen",
        "inq_placeholder_company": "Musterfirma GmbH",
        "inq_label_name": "Name des Ansprechpartners",
        "inq_placeholder_name": "Max Mustermann",
        "inq_label_email": "E-Mail-Adresse",
        "inq_placeholder_email": "kontakt@firma.de",
        "inq_label_phone": "Telefonnummer",
        "inq_placeholder_phone": "+49 (0) 511 ...",
        "inq_label_service": "Gewünschte Dienstleistung",
        "inq_opt_select": "-- Bitte auswählen --",
        "inq_opt_general": "Gebäudereinigung",
        "inq_opt_maintenance": "Unterhaltsreinigung",
        "inq_opt_special": "Sonderreinigung",
        "inq_opt_other": "Andere Dienstleistungen",
        "inq_label_message": "Objektdetails (z.B. geschätzte Quadratmeter, Reinigungsfrequenz)",
        "inq_placeholder_message": "Bitte geben Sie uns hier ein paar Details zu Ihrem Anliegen...",
        "inq_btn_submit": "Detaillierte Anfrage absenden",
        "inq_disclaimer": "Mit dem Absenden dieses Formulars stimmen Sie unserer Datenschutzerklärung zu. Ihre Daten werden SSL-verschlüsselt übertragen.",
        "inq_success_title": "Anfrage erfolgreich übermittelt",
        "inq_success_msg": "Vielen Dank für Ihre detaillierte Anfrage. Scott Gerke wird sich persönlich mit Ihnen in Verbindung setzen, um Ihnen ein maßgeschneidertes B2B-Angebot zu unterbreiten.",

        // Imprint Page (imprint.html)
        "imprint_hero_title": "Impressum",
        "imprint_hero_desc": "Gesetzliche Angaben gemäß § 5 TMG.",
        "imprint_operator_title": "Angaben gemäß § 5 TMG",
        "imprint_operator_text": "Scott Gerke<br>Einzelunternehmer / Inhaber<br>Kattenbrookstrift<br>30539 Hannover<br>Deutschland",
        "imprint_contact_title": "Kontakt",
        "imprint_contact_text": "Telefon: 0511 11721912<br>E-Mail: info@aquil-alliance.de",
        "imprint_vat_title": "Umsatzsteuer-ID",
        "imprint_vat_text": "Umsatzsteuer-Identifikationsnummer gemäß § 27 a Umsatzsteuergesetz:<br>DE 345 678 910",
        "imprint_court_title": "Aufsichtsbehörde / Register",
        "imprint_court_text": "Amtsgericht Hannover<br>Registernummer: HRB 230128",
        "imprint_disclaimer_title": "Haftungsausschluss",
        "imprint_disclaimer_text": "Wir übernehmen keine Haftung für die Inhalte externer Links. Für den Inhalt verlinkter Seiten sind ausschließlich deren Betreiber verantwortlich.",

        // Privacy Policy Page (privacy.html)
        "privacy_hero_title": "Datenschutz",
        "privacy_hero_desc": "Informationen über die Verarbeitung Ihrer personenbezogenen Daten.",
        "privacy_sec_1_title": "1. Datenschutz auf einen Blick",
        "privacy_sec_1_text": "Der Schutz Ihrer persönlichen Daten ist uns ein wichtiges Anliegen. Wir verarbeiten Ihre Daten ausschließlich auf Grundlage der gesetzlichen Bestimmungen (DSGVO, BDSG).",
        "privacy_sec_2_title": "2. Datenerfassung auf unserer Website",
        "privacy_sec_2_text": "Wenn Sie uns per Rückruf- oder Angebotsformular Anfragen zukommen lassen, werden Ihre Angaben zwecks Bearbeitung der Anfrage und für den Fall von Anschlussfragen bei uns gespeichert. Diese Daten geben wir niemals ohne Ihre Einwilligung weiter.",
        "privacy_sec_3_title": "3. Ihre Rechte",
        "privacy_sec_3_text": "Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung, Datenübertragbarkeit, Widerruf und Widerspruch bezüglich Ihrer gespeicherten personenbezogenen Daten. Wenden Sie sich hierzu bitte an info@aquil-alliance.de.",

        // Footer (Shared)
        "footer_sub": "Scott Gerke (Einzelunternehmer)<br>Professionelle Gebäudereinigung & Facility Services für höchste Ansprüche.",
        "footer_location_title": "Standort",
        "footer_location_address": "Kattenbrookstrift<br>30539 Hannover<br>Deutschland",
        "footer_contact_title": "Kontakt",
        "footer_rights": "© 2026 AQUIL Alliance. Alle Rechte vorbehalten.",
        "footer_legal_impressum": "Impressum",
        "footer_legal_privacy": "Datenschutz",
        "footer_legal_court": "Amtsgericht Hannover",
        "footer_legal_hrb": "HRB 230128",

        // Modals (Shared)
        "btn_close": "Schließen"
    },
    en: {
        // Navigation (Shared)
        "nav_home": "Home",
        "nav_about": "About Us",
        "nav_services": "Services",
        "nav_contact": "Contact",
        "nav_service_general": "Building Cleaning",
        "nav_service_maintenance": "Maintenance Cleaning",
        "nav_service_special": "Special Cleaning",
        "btn_inquire": "Inquire Now",
        "phone_call": "+49 511 11721912",

        // Home Page
        "hero_title_1": "Professional.",
        "hero_title_2": "Reliable.",
        "hero_desc": "Your cleanliness is our commitment. Uncompromising quality and German engineering precision in commercial cleaning for demanding B2B clients in Hanover and the surrounding region.",
        "hero_cta_inquire": "Inquire Now",
        "hero_cta_discover": "Discover Services",
        "val_1_title": "On-Time",
        "val_1_desc": "Absolute punctuality. We integrate seamlessly into your business operations without causing disruption.",
        "val_2_title": "Detailed",
        "val_2_desc": "Microscopic precision. We don't just clean surfaces, we preserve the value of your real estate.",
        "val_3_title": "Trustworthy",
        "val_3_desc": "Security and discretion. Trust is the foundation of our long-term partnerships.",
        "val_4_title": "Eco-friendly",
        "val_4_desc": "Sustainable cleaning concepts and environmentally friendly products for a clean future.",
        "services_sub": "Core Competencies",
        "services_title": "Our Service Portfolio",
        "services_all": "All Services",
        "srv_1_num": "01",
        "srv_1_title": "Building Cleaning",
        "srv_1_desc": "Comprehensive care for your property. From the facade to the underground garage floor. We guarantee value retention and a pristine appearance for your representative assets.",
        "srv_1_bullet_1": "Facade & Window Cleaning",
        "srv_1_bullet_2": "Stairwell Cleaning",
        "srv_1_bullet_3": "Outer Facility Maintenance",
        "srv_1_details": "View Details",
        "srv_2_num": "02",
        "srv_2_title": "Maintenance Cleaning",
        "srv_2_desc": "Regular cleaning at fixed intervals. Perfect for offices, medical practices, and law firms.",
        "srv_2_details": "Learn More",
        "srv_3_num": "03",
        "srv_3_title": "Special Cleaning",
        "srv_3_desc": "Specialized solutions for tough cases. Deep cleaning, post-construction cleaning, and industrial plants.",
        "srv_3_details": "Learn More",
        "promise_title": "Our Promise",
        "promise_desc": "We respond within 2 hours to your request during business hours. Guaranteed. Leave your number, and we will call you back immediately for a free, non-binding initial consultation.",
        "promise_phone_label": "Direct Contact",
        "callback_title": "Request Callback",
        "form_label_name": "Name / Company",
        "form_placeholder_name": "John Doe Corp.",
        "form_label_phone": "Phone Number",
        "form_placeholder_phone": "+49 (0) ...",
        "form_btn_submit": "Request Callback",
        "form_disclaimer": "By submitting this form, you agree to our privacy policy. We use your data exclusively for contacting you.",
        "form_success_title": "Request Sent Successfully",
        "form_success_msg": "Thank you for your request. We will contact you within the next 2 hours.",
        "form_error_empty": "Please fill in all required fields.",
        "form_error_phone": "Please enter a valid phone number.",

        // Stats Section
        "stats_title": "AQUIL in Numbers",
        "stat_1_number": "500+",
        "stat_1_label": "Properties Cleaned",
        "stat_2_number": "99%",
        "stat_2_label": "Customer Satisfaction",
        "stat_3_number": "2h",
        "stat_3_label": "Response Time",
        "stat_4_number": "24/7",
        "stat_4_label": "Emergency Service",

        // Testimonials Section
        "testimonials_sub": "Client Voices",
        "testimonials_title": "What Our Clients Say",
        "testimonial_1_text": "AQUIL Alliance exceeded our expectations. The thoroughness and reliability of their team is unmatched. Our offices have never been cleaner.",
        "testimonial_1_name": "Thomas Richter",
        "testimonial_1_role": "CEO, Richter Immobilien GmbH",
        "testimonial_2_text": "As a practice owner, I place the highest value on hygiene. AQUIL consistently delivers first-class results. Communication is exemplary.",
        "testimonial_2_name": "Dr. Sabine Weber",
        "testimonial_2_role": "Owner, Weber Dental Practice",
        "testimonial_3_text": "Since working with AQUIL, we haven't received a single complaint. Punctual, discreet, and absolutely professional.",
        "testimonial_3_name": "Michael Hoffmann",
        "testimonial_3_role": "Facility Manager, Expo Park Hanover",

        // Process Section
        "process_sub": "How We Work",
        "process_title": "4 Steps to Your Clean Property",
        "process_1_title": "Inquiry",
        "process_1_desc": "Contact us by phone, email, or form. We respond within 2 hours.",
        "process_2_title": "Inspection",
        "process_2_desc": "We inspect your property free of charge and create a tailored cleaning plan.",
        "process_3_title": "Quote",
        "process_3_desc": "You receive a transparent, fair quote with no hidden costs.",
        "process_4_title": "Execution",
        "process_4_desc": "Our trained team starts on schedule with professional cleaning.",

        // Trust Marquee
        "trust_item_1": "Professional",
        "trust_item_2": "Reliable",
        "trust_item_3": "On-Time",
        "trust_item_4": "Eco-Friendly",
        "trust_item_5": "Hanover & Region",
        "trust_item_6": "B2B Specialist",

        // About Us Page (about.html)
        "about_hero_title": "About Us",
        "about_hero_desc": "Get to know AQUIL Alliance and our core values. We stand for reliability, precision, and commercial asset preservation.",
        "about_story_title": "Our Story",
        "about_story_p1": "AQUIL Alliance was founded by Scott Gerke as an owner-operated sole proprietorship in Hanover. Focused on the demands of premium commercial clients, we deliver tailored cleaning solutions with a clear quality commitment.",
        "about_story_p2": "We do not view ourselves merely as a service provider, but as a long-term partner in facility management. Our flat hierarchies guarantee fast response times and a dedicated, competent manager on-site.",
        "about_values_title": "What Sets Us Apart",
        "about_val_1_title": "Owner-Operated",
        "about_val_1_desc": "Direct accountability by Scott Gerke. No long corporate channels, just prompt executive decisions.",
        "about_val_2_title": "Hanover & Region",
        "about_val_2_desc": "We are locally rooted and fast on-site. Short travel distances enable high flexibility and emergency response.",
        "about_val_3_title": "Modern Equipment",
        "about_val_3_desc": "We clean with state-of-the-art machinery and environmentally sensitive products for top-tier results.",
        "about_quality_title": "Quality Guarantee",
        "about_quality_desc": "Through regular property checks and permanent staff members, we secure a consistently high level of cleaning. Our quality commitment is non-negotiable.",

        // Services Page (services.html)
        "services_hero_title": "Services",
        "services_hero_desc": "Our service spectrum covers all facets of professional B2B building cleaning. Learn more here about our core competencies.",
        "services_cta_inquire": "Inquire for Service",
        "services_item_1_title": "Building Cleaning",
        "services_item_1_desc": "A well-maintained property is the calling card of your company. We take care of the full interior and exterior cleaning of your commercial assets to secure sustainable value preservation.",
        "services_item_1_li1": "Glass, frame and facade cleaning",
        "services_item_1_li2": "Stairwells, hallways and entrance lobbies",
        "services_item_1_li3": "Underground garages, parking lots and pathways",
        "services_item_1_li4": "Sanitary facilities and staff lounges",
        "services_item_2_title": "Maintenance Cleaning",
        "services_item_2_desc": "Regular maintenance cleaning in fixed intervals ensures a hygienic and productive working environment in your offices, agencies, or medical centers.",
        "services_item_2_li1": "Workplace and desk surface cleaning",
        "services_item_2_li2": "Floor maintenance (vacuuming, damp mopping)",
        "services_item_2_li3": "Emptying trash bins & proper waste separation",
        "services_item_2_li4": "Kitchens, breakrooms, and coffee machine maintenance",
        "services_item_3_title": "Special Cleaning",
        "services_item_3_desc": "Special requirements demand professional specialized solutions. We perform intensive cleaning operations that go beyond normal maintenance intervals.",
        "services_item_3_li1": "Post-construction cleaning (rough and final handovers)",
        "services_item_3_li2": "Deep cleaning and sealing of hard floor surfaces",
        "services_item_3_li3": "Carpet deep cleaning and upholstery shampooing",
        "services_item_3_li4": "Industrial facility and machinery cleaning",

        // Inquiry Page (inquiry.html)
        "inq_hero_title": "Inquire Now",
        "inq_hero_desc": "Request a free, individual quote. Please fill out the detailed inquiry form below. We will get back to you immediately.",
        "inq_form_header": "Details of Your Inquiry",
        "inq_label_company": "Company / Enterprise",
        "inq_placeholder_company": "Example Corp.",
        "inq_label_name": "Contact Person Name",
        "inq_placeholder_name": "John Doe",
        "inq_label_email": "Email Address",
        "inq_placeholder_email": "contact@company.com",
        "inq_label_phone": "Phone Number",
        "inq_placeholder_phone": "+49 (0) 511 ...",
        "inq_label_service": "Requested Service",
        "inq_opt_select": "-- Please select --",
        "inq_opt_general": "Building Cleaning",
        "inq_opt_maintenance": "Maintenance Cleaning",
        "inq_opt_special": "Special Cleaning",
        "inq_opt_other": "Other Services",
        "inq_label_message": "Object Details (e.g. estimated area, frequency of cleaning)",
        "inq_placeholder_message": "Please give us a few details about your requirements here...",
        "inq_btn_submit": "Submit Detailed Inquiry",
        "inq_disclaimer": "By submitting this form, you agree to our privacy policy. Your data is transmitted with SSL encryption.",
        "inq_success_title": "Inquiry Submitted Successfully",
        "inq_success_msg": "Thank you for your detailed inquiry. Scott Gerke will personally contact you to present a customized B2B offer.",

        // Imprint Page (imprint.html)
        "imprint_hero_title": "Imprint",
        "imprint_hero_desc": "Legal disclosures in accordance with § 5 TMG.",
        "imprint_operator_title": "Details according to § 5 TMG",
        "imprint_operator_text": "Scott Gerke<br>Sole Proprietor / Owner<br>Kattenbrookstrift<br>30539 Hanover<br>Germany",
        "imprint_contact_title": "Contact",
        "imprint_contact_text": "Phone: +49 511 11721912<br>Email: info@aquil-alliance.de",
        "imprint_vat_title": "VAT ID",
        "imprint_vat_text": "VAT identification number according to § 27 a of the German VAT Act:<br>DE 345 678 910",
        "imprint_court_title": "Regulatory Authority / Register",
        "imprint_court_text": "Hanover District Court<br>Registration Number: HRB 230128",
        "imprint_disclaimer_title": "Disclaimer",
        "imprint_disclaimer_text": "We assume no liability for the content of external links. The operators of the linked pages are solely responsible for their content.",

        // Privacy Policy Page (privacy.html)
        "privacy_hero_title": "Privacy Policy",
        "privacy_hero_desc": "Information on the processing of your personal data.",
        "privacy_sec_1_title": "1. Privacy at a Glance",
        "privacy_sec_1_text": "The protection of your personal data is an important concern to us. We process your data exclusively in accordance with statutory regulations (GDPR, BDSG).",
        "privacy_sec_2_title": "2. Data Collection on Our Website",
        "privacy_sec_2_text": "If you send us inquiries via the callback or inquiry forms, your data will be stored for processing and potential follow-up questions. We never share this data without your explicit consent.",
        "privacy_sec_3_title": "3. Your Rights",
        "privacy_sec_3_text": "You have the right to request free information on the origin, recipient, and purpose of your stored personal data. You also have the right to correct or delete this data. Please address inquiries to info@aquil-alliance.de.",

        // Footer (Shared)
        "footer_sub": "Scott Gerke (Sole Trader)<br>Professional building cleaning & facility services for the highest demands.",
        "footer_location_title": "Location",
        "footer_location_address": "Kattenbrookstrift<br>30539 Hanover<br>Germany",
        "footer_contact_title": "Contact",
        "footer_rights": "© 2026 AQUIL Alliance. All rights reserved.",
        "footer_legal_impressum": "Imprint",
        "footer_legal_privacy": "Privacy Policy",
        "footer_legal_court": "Hanover District Court",
        "footer_legal_hrb": "HRB 230128",

        // Modals (Shared)
        "btn_close": "Close"
    }
};

// Global App State
let currentLang = 'en';

// Translate All elements marked with data-i18n
function translatePage(lang) {
    currentLang = lang;
    localStorage.setItem('aquil_lang', lang);

    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (translations[lang][key]) {
            // Check if element is an input with placeholders
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.placeholder = translations[lang][key];
            } else {
                element.innerHTML = translations[lang][key];
            }
        }
    });

    // Update document title page-specific
    let baseTitle = "AQUIL Alliance";
    const titleKey = document.querySelector('[data-page-title-key]');
    if (titleKey) {
        const key = titleKey.getAttribute('data-page-title-key');
        if (translations[lang][key]) {
            baseTitle = `${translations[lang][key]} | AQUIL Alliance`;
        }
    } else {
        baseTitle = lang === 'de' 
            ? "AQUIL Alliance - Professionelle Gebäudereinigung" 
            : "AQUIL Alliance - Professional Commercial Cleaning";
    }
    document.title = baseTitle;

    // Update active class on language toggle buttons
    document.querySelectorAll('.lang-btn').forEach(btn => {
        if (btn.getAttribute('data-lang') === lang) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    // Update page lang attribute
    document.documentElement.setAttribute('lang', lang);
}

// Detect User Language
function detectLanguage() {
    // 1. Check local storage
    const savedLang = localStorage.getItem('aquil_lang');
    if (savedLang && (savedLang === 'en' || savedLang === 'de')) {
        return savedLang;
    }

    // 2. Check browser language
    const browserLang = navigator.language || navigator.userLanguage;
    if (browserLang && browserLang.toLowerCase().startsWith('de')) {
        return 'de';
    }

    // 3. Default to English
    return 'en';
}

// Handle smooth scroll anchor for #callback-section
function handleHashScroll() {
    if (window.location.hash === '#callback-section') {
        const target = document.getElementById('callback-section');
        if (target) {
            // Wait slightly for DOM positioning
            setTimeout(() => {
                target.scrollIntoView({ behavior: 'smooth' });
            }, 150);
        }
    }
}

function showFieldError(inputEl, message) {
    let errorEl = inputEl.parentElement.querySelector('.error-message');
    if (!errorEl) {
        errorEl = document.createElement('span');
        errorEl.className = 'error-message';
        inputEl.parentElement.appendChild(errorEl);
    }
    errorEl.textContent = message;
    errorEl.classList.add('visible');
}

// Initialize i18n and global page controls
document.addEventListener('DOMContentLoaded', () => {
    const lang = detectLanguage();
    translatePage(lang);
    handleHashScroll();

    // Check for hash changes dynamically (e.g. if already on home page and clicking contact)
    window.addEventListener('hashchange', handleHashScroll);

    // ===== SCROLL REVEAL ANIMATION =====
    const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');
    if (revealElements.length > 0) {
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -60px 0px'
        });
        revealElements.forEach(el => revealObserver.observe(el));
    }

    // ===== COUNTER ANIMATION =====
    const counterElements = document.querySelectorAll('[data-counter]');
    if (counterElements.length > 0) {
        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const el = entry.target;
                    const target = el.getAttribute('data-counter');
                    // Check if target is a number
                    const numericPart = parseInt(target);
                    if (!isNaN(numericPart)) {
                        const suffix = target.replace(/[0-9]/g, '');
                        let current = 0;
                        const increment = Math.max(1, Math.floor(numericPart / 60));
                        const timer = setInterval(() => {
                            current += increment;
                            if (current >= numericPart) {
                                current = numericPart;
                                clearInterval(timer);
                            }
                            el.textContent = current + suffix;
                        }, 25);
                    } else {
                        el.textContent = target;
                    }
                    counterObserver.unobserve(el);
                }
            });
        }, { threshold: 0.3 });
        counterElements.forEach(el => counterObserver.observe(el));
    }

    // Setup Language Button Switchers
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const selectedLang = btn.getAttribute('data-lang');
            translatePage(selectedLang);
        });
    });

    // Setup Mobile Navigation Menu
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileDrawer = document.getElementById('mobile-drawer');
    const closeMobileMenuBtn = document.getElementById('close-mobile-menu-btn');
    const mobileLinks = document.querySelectorAll('.mobile-link');

    function toggleMobileMenu() {
        if (mobileDrawer) {
            mobileDrawer.classList.toggle('translate-x-full');
        }
    }

    if (mobileMenuBtn && mobileDrawer) {
        mobileMenuBtn.addEventListener('click', toggleMobileMenu);
    }
    if (closeMobileMenuBtn) {
        closeMobileMenuBtn.addEventListener('click', toggleMobileMenu);
    }
    mobileLinks.forEach(link => {
        link.addEventListener('click', () => {
            // Close mobile menu
            if (mobileDrawer && !mobileDrawer.classList.contains('translate-x-full')) {
                toggleMobileMenu();
            }
        });
    });

    // Setup Mobile Dropdown for Services
    const mobileDropdownBtn = document.getElementById('mobile-dropdown-btn');
    const mobileDropdownContent = document.getElementById('mobile-dropdown-content');
    if (mobileDropdownBtn && mobileDropdownContent) {
        mobileDropdownBtn.addEventListener('click', (e) => {
            e.preventDefault();
            mobileDropdownContent.classList.toggle('hidden');
        });
    }

    // Form submission modals elements
    const feedbackModal = document.getElementById('feedback-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalMessage = document.getElementById('modal-message');
    const modalCloseBtn = document.getElementById('modal-close-btn');

    // Setup Short Callback Form (Home Page)
    const callbackForm = document.getElementById('callback-form');
    if (callbackForm) {
        callbackForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const nameInput = document.getElementById('name');
            const phoneInput = document.getElementById('phone');
            let valid = true;

            // Clear previous errors
            document.querySelectorAll('.error-message').forEach(em => em.classList.remove('visible'));
            document.querySelectorAll('.field-error').forEach(fe => fe.classList.remove('field-error'));

            if (!nameInput.value.trim()) {
                nameInput.classList.add('field-error');
                showFieldError(nameInput, translations[currentLang]['form_error_empty']);
                valid = false;
            }
            if (!phoneInput.value.trim()) {
                phoneInput.classList.add('field-error');
                showFieldError(phoneInput, translations[currentLang]['form_error_empty']);
                valid = false;
            }

            if (!valid) return;

            if (feedbackModal && modalTitle && modalMessage) {
                modalTitle.textContent = translations[currentLang]['form_success_title'];
                modalMessage.textContent = translations[currentLang]['form_success_msg'];
                feedbackModal.classList.remove('hidden');
                feedbackModal.classList.add('flex');
            }

            nameInput.value = '';
            phoneInput.value = '';
        });
    }

    // Setup Detailed Inquiry Form (Inquiry Page)
    const inquiryForm = document.getElementById('inquiry-form');
    if (inquiryForm) {
        inquiryForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const compInput = document.getElementById('inq-company');
            const nameInput = document.getElementById('inq-name');
            const emailInput = document.getElementById('inq-email');
            const phoneInput = document.getElementById('inq-phone');
            const serviceInput = document.getElementById('inq-service');
            const messageInput = document.getElementById('inq-message');

            if (!nameInput.value.trim() || !emailInput.value.trim() || !phoneInput.value.trim()) {
                alert(translations[currentLang]["form_error_empty"]);
                return;
            }

            if (feedbackModal && modalTitle && modalMessage) {
                modalTitle.textContent = translations[currentLang]["inq_success_title"];
                modalMessage.textContent = translations[currentLang]["inq_success_msg"];
                feedbackModal.classList.remove('hidden');
                feedbackModal.classList.add('flex');
            }

            // Reset form fields
            compInput.value = '';
            nameInput.value = '';
            emailInput.value = '';
            phoneInput.value = '';
            serviceInput.value = '';
            messageInput.value = '';
        });
    }

    if (modalCloseBtn && feedbackModal) {
        modalCloseBtn.addEventListener('click', () => {
            feedbackModal.classList.add('hidden');
            feedbackModal.classList.remove('flex');
        });
    }
});
